// src/app/page.tsx
'use client';

import { useState, useEffect } from 'react'; // Import useEffect
import { useSearchParams } from 'next/navigation'; // Import useSearchParams
import Layout from '../components/Layout';
import SignInForm from '../components/SignInForm';
import SignUpForm from '../components/SignUpForm';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../redux/store';
import { useRouter } from 'next/navigation';



export default function HomePage() {
  const searchParams = useSearchParams();
  const formType = searchParams.get('form'); // Read 'form' query parameter

  const isAuthenticated = useSelector((state: RootState) => state.auth.isAuthenticated);
  const router = useRouter();

    // --- Route Protection ---
    useEffect(() => {
      if (isAuthenticated) {
        router.push('/dashboard'); // Redirect to sign-in if not authenticated
      }
    }, [isAuthenticated, router]);

  // Initialize showSignIn based on the URL parameter
  // Default to true (show sign-in) if no parameter or invalid parameter
  const [showSignIn, setShowSignIn] = useState(formType !== 'signup');

  // Use useEffect to update showSignIn if the URL parameter changes
  useEffect(() => {
    setShowSignIn(formType !== 'signup');
  }, [formType]); // Re-run when formType changes

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center">
        {showSignIn ? <SignInForm /> : <SignUpForm />}
        <button
          onClick={() => {
            const newShowSignIn = !showSignIn;
            setShowSignIn(newShowSignIn);
            // Update the URL to reflect the current form state
            // This allows direct linking to a specific form and persists state on refresh
            const newFormType = newShowSignIn ? 'signin' : 'signup';
            // Use replace instead of push to avoid adding many entries to browser history
            window.history.replaceState({}, '', `/?form=${newFormType}`);
          }}
          className="mt-4 text-blue-500 hover:underline"
        >
          {showSignIn ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
        </button>
      </div>
    </Layout>
  );
}