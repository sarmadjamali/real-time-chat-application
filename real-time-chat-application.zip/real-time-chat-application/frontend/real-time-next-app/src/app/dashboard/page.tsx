// src/app/dashboard/page.tsx
'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../redux/store';
import { useRouter } from 'next/navigation';
import Layout from '../../components/Layout';
import { clearAuthTokens } from '../../redux/authSlice';
import ConversationList from '../../components/chat/ConversationList';
import MessagePanel from '../../components/chat/MessagePanel';
import NewConversationModal from '../../components/chat/NewConversationModal';

// Define types for data coming from the backend
interface Conversation {
  id: string;
  name: string; // Or a concatenated list of participant names
  lastMessage?: string;
  participants: { id: string; name: string }[];
}

interface Message {
  id: string;
  sender_id: string;
  content: string;
  timestamp: string; // ISO string
}

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  // Add other user properties as needed
}

export default function DashboardPage() {
  const router = useRouter();
  const dispatch = useDispatch();
  const isAuthenticated = useSelector((state: RootState) => state.auth.isAuthenticated);
  const accessToken = useSelector((state: RootState) => state.auth.accessToken);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [showNewConversationModal, setShowNewConversationModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null); // To store current user's ID/info

  // --- Route Protection ---
  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/'); // Redirect to sign-in if not authenticated
    }
  }, [isAuthenticated, router]);

  // --- Fetch Current User Info (Optional, but useful for identifying self in chat) ---
  // Assuming your backend has an endpoint like /me or /users/current
  const fetchCurrentUser = useCallback(async () => {
    if (!accessToken) return;

    try {
      const response = await fetch('http://localhost:8000/me', { // Example endpoint for current user
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const user: User = await response.json();
        setCurrentUser(user);
      } else {
        console.error('Failed to fetch current user:', response.status);
        // If token is invalid, force logout
        if (response.status === 401) {
          dispatch(clearAuthTokens());
          router.push('/');
        }
      }
    } catch (error) {
      console.error('Error fetching current user:', error);
    }
  }, [accessToken, dispatch, router]);

  useEffect(() => {
    fetchCurrentUser();
  }, [fetchCurrentUser]);


  // --- Fetch Conversations ---
  const fetchConversations = useCallback(async () => {
    if (!accessToken) return;

    try {
      const response = await fetch('http://localhost:8000/conversations', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data: Conversation[] = await response.json();
        setConversations(data);
        // If no conversation is selected, or the previously selected one is gone, select the first one
        if (!selectedConversation || !data.some(conv => conv.id === selectedConversation.id)) {
          if (data.length > 0) {
            setSelectedConversation(data[0]);
          } else {
            setSelectedConversation(null); // No conversations to select
          }
        }
      } else {
        console.error('Failed to fetch conversations:', response.status);
        if (response.status === 401) {
          dispatch(clearAuthTokens());
          router.push('/');
        }
      }
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  }, [accessToken, dispatch, router, selectedConversation]);

  useEffect(() => {
    fetchConversations();
    // Set up polling for conversations (e.g., every 10 seconds)
    const interval = setInterval(fetchConversations, 10000); // Poll every 10 seconds
    return () => clearInterval(interval); // Clean up on unmount
  }, [fetchConversations]);

  // --- Fetch Messages for Selected Conversation ---
  const fetchMessages = useCallback(async (conversationId: string) => {
    if (!accessToken) return;

    try {
      const response = await fetch(`http://localhost:8000/messages`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data: Message[] = await response.json();
        setMessages(data);
      } else {
        console.error(`Failed to fetch messages for conversation ${conversationId}:`, response.status);
        if (response.status === 401) {
          dispatch(clearAuthTokens());
          router.push('/');
        }
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  }, [accessToken, dispatch, router]);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation.id);
      // Set up polling for messages (e.g., every 3 seconds)
      const interval = setInterval(() => fetchMessages(selectedConversation.id), 3000); // Poll every 3 seconds
      return () => clearInterval(interval); // Clean up on unmount
    } else {
      setMessages([]); // Clear messages if no conversation is selected
    }
  }, [selectedConversation, fetchMessages]);

  // --- Handle Sending Message ---
  const handleSendMessage = useCallback(async (content: string) => {
    if (!accessToken || !selectedConversation || !content.trim()) return;

    try {
      const response = await fetch(`http://localhost:8000/conversations/${selectedConversation.id}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      });

      if (response.ok) {
        // After sending, re-fetch messages to update the UI
        fetchMessages(selectedConversation.id);
        // Optionally, update the last message in the conversations list
        fetchConversations();
      } else {
        console.error('Failed to send message:', response.status);
        alert('Failed to send message.');
        if (response.status === 401) {
          dispatch(clearAuthTokens());
          router.push('/');
        }
      }
    } catch (error) {
      console.error('Error sending message:', error);
      alert('An error occurred while sending message.');
    }
  }, [accessToken, selectedConversation, fetchMessages, fetchConversations, dispatch, router]);

  // --- Handle Starting New Conversation ---
  const handleStartNewConversation = useCallback(async (participantIds: string[]) => {
    if (!accessToken || !currentUser) return;

    // Ensure the current user is always a participant
    const allParticipantIds = Array.from(new Set([...participantIds, currentUser.id]));

    try {
      const response = await fetch('http://localhost:8000/conversations', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ participant_ids: allParticipantIds }),
      });

      if (response.ok) {
        const newConversation: Conversation = await response.json();
        alert('New conversation started!');
        setShowNewConversationModal(false);
        fetchConversations(); // Refresh conversation list
        setSelectedConversation(newConversation); // Select the new conversation
      } else {
        console.error('Failed to start new conversation:', response.status);
        alert('Failed to start new conversation.');
        if (response.status === 401) {
          dispatch(clearAuthTokens());
          router.push('/');
        }
      }
    } catch (error) {
      console.error('Error starting new conversation:', error);
      alert('An error occurred while starting a new conversation.');
    }
  }, [accessToken, currentUser, fetchConversations, dispatch, router]);


  // --- Render Protection ---
  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="text-center text-gray-600">Redirecting to login...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col h-[calc(100vh-120px)] w-full max-w-7xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden">
        {/* Chat Header */}
        <div className="flex justify-between items-center p-4 bg-gray-800 text-white shadow-md">
          <h1 className="text-2xl font-semibold">Real-time Chat</h1>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowNewConversationModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full shadow-lg transition duration-300 ease-in-out transform hover:scale-105"
            >
              + New Message
            </button>
            <button
              onClick={() => {
                dispatch(clearAuthTokens());
                router.push('/');
              }}
              className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full shadow-lg transition duration-300 ease-in-out transform hover:scale-105"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Chat Body */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left Panel: Conversations List */}
          <div className="w-1/4 bg-gray-100 border-r border-gray-200 overflow-y-auto">
            <ConversationList
              conversations={conversations}
              selectedConversation={selectedConversation}
              onSelectConversation={setSelectedConversation}
              currentUser={currentUser}
            />
          </div>

          {/* Middle Panel: Message Display */}
          <div className="flex-1 flex flex-col bg-white">
            {selectedConversation ? (
              <MessagePanel
                conversation={selectedConversation}
                messages={messages}
                onSendMessage={handleSendMessage}
                currentUser={currentUser}
              />
            ) : (
              <div className="flex flex-1 items-center justify-center text-gray-500">
                Select a conversation or start a new one.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New Conversation Modal */}
      {showNewConversationModal && (
        <NewConversationModal
          onClose={() => setShowNewConversationModal(false)}
          onStartConversation={handleStartNewConversation}
          accessToken={accessToken}
          currentUser={currentUser}
        />
      )}
    </Layout>
  );
}
