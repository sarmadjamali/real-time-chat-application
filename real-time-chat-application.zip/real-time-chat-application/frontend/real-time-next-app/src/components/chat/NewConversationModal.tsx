// src/components/chat/NewConversationModal.tsx
'use client';

import React, { useState, useEffect, useCallback } from 'react';

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
}

interface NewConversationModalProps {
  onClose: () => void;
  onStartConversation: (participantIds: string[]) => void;
  accessToken: string | null;
  currentUser: User | null;
}

const NewConversationModal: React.FC<NewConversationModalProps> = ({
  onClose,
  onStartConversation,
  accessToken,
  currentUser
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch users from the backend
  const fetchUsers = useCallback(async () => {
    if (!accessToken) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('http://localhost:8000/users', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data: User[] = await response.json();
        // Filter out the current user from the list of selectable users
        const filteredUsers = data.filter(user => currentUser && user.id !== currentUser.id);
        setUsers(filteredUsers);
      } else {
        const errorData = await response.json();
        setError(`Failed to fetch users: ${errorData.message || response.statusText}`);
      }
    } catch (err) {
      console.error('Error fetching users:', err);
      setError('An error occurred while fetching users.');
    } finally {
      setIsLoading(false);
    }
  }, [accessToken, currentUser]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleUserSelect = (user: User) => {
    setSelectedUsers((prevSelected) => {
      if (prevSelected.some((u) => u.id === user.id)) {
        return prevSelected.filter((u) => u.id !== user.id); // Deselect
      } else {
        return [...prevSelected, user]; // Select
      }
    });
  };

  const handleStartChat = () => {
    if (selectedUsers.length === 0) {
      alert('Please select at least one user to start a conversation.');
      return;
    }
    const participantIds = selectedUsers.map(user => user.id);
    onStartConversation(participantIds);
  };

  const filteredUsers = users.filter(user =>
    user.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 text-2xl font-bold"
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Start New Conversation</h2>

        {/* Selected Users */}
        {selectedUsers.length > 0 && (
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="text-md font-semibold mb-2 text-gray">Selected:</h3>
            <div className="flex flex-wrap gap-2">
              {selectedUsers.map(user => (
                <span
                  key={user.id}
                  className="bg-blue-200 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center"
                >
                  {user.first_name} {user.last_name}
                  <button
                    onClick={() => handleUserSelect(user)}
                    className="ml-2 text-blue-600 hover:text-blue-800 font-bold"
                  >
                    &times;
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Search Input */}
        <div className="mb-4">
          <input
            type="text"
            placeholder="Search users by name or email..."
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* User List */}
        <div className="h-64 overflow-y-auto border border-gray-300 rounded-lg p-2 mb-4">
          {isLoading ? (
            <div className="text-center text-gray-500 py-4">Loading users...</div>
          ) : error ? (
            <div className="text-center text-red-500 py-4">{error}</div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center text-gray-500 py-4">No users found.</div>
          ) : (
            <ul>
              {filteredUsers.map((user) => (
                <li
                  key={user.id}
                  className={`flex items-center p-2 rounded-md cursor-pointer hover:bg-gray-100 transition duration-150 ease-in-out
                    ${selectedUsers.some(u => u.id === user.id) ? 'bg-blue-100' : ''}`}
                  onClick={() => handleUserSelect(user)}
                >
                  <div className="flex-shrink-0 w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">
                    {user.first_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{user.first_name} {user.last_name}</p>
                    <p className="text-sm text-gray-600">{user.email}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400 transition duration-200"
          >
            Cancel
          </button>
          <button
            onClick={handleStartChat}
            className="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200"
          >
            Start Chat
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewConversationModal;
