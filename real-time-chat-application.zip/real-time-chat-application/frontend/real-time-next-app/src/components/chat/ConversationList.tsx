// src/components/chat/ConversationList.tsx
import React from 'react';

interface Conversation {
    id: string;
    name: string;
    sender:User,
    receiver:User
  //   participants: { id: string; name: string }[];
  }

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
}

interface ConversationListProps {
  conversations: Conversation[];
  selectedConversation: Conversation | null;
  onSelectConversation: (conversation: Conversation) => void;
  currentUser: User | null;
}

const ConversationList: React.FC<ConversationListProps> = ({
  conversations,
  selectedConversation,
  onSelectConversation,
  currentUser
}) => {
    console.log(conversations)
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Conversations</h2>
      {
      
      conversations.length === 0 ? (
        <p className="text-gray-500 text-sm">No conversations yet. Start a new one!</p>
      ) : (
        <ul>
          {conversations.map((conv) => {
            // Determine conversation name based on participants, excluding current user

    
            // const otherParticipants = conv.sender.id.filter(
            //   p => currentUser && p.id !== currentUser.id
            // );
            // const conversationName = otherParticipants.length > 0
            //   ? otherParticipants.map(p => `${p.first_name} ${p.last_name}`).join(', ')
            //   : 'Self Chat'; // Or a default name if only self in chat
            
            const conversationName = conv.sender; 

            return (
              <li
                key={conv.id}
                className={`flex items-center p-3 rounded-lg mb-2 cursor-pointer transition duration-200 ease-in-out
                  ${selectedConversation?.id === conv.id ? 'bg-blue-100 shadow-md' : 'hover:bg-gray-200'}`}
                onClick={() => onSelectConversation(conv)}
              >
                <div className="flex-shrink-0 w-10 h-10 bg-blue-500 text-white rounded-full flex items-center justify-center font-bold mr-3">
                  {conversationName.first_name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-800 text-lg">{conversationName.first_name}</h3>
                  {conv.lastMessage && (
                    <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

export default ConversationList;
