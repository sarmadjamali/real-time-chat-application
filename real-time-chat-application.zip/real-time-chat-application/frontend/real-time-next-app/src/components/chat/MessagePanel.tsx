// src/components/chat/MessagePanel.tsx
import React, { useState, useRef, useEffect } from 'react';

interface Conversation {
  id: string;
  name: string;
  sender:User,
  receiver:User,
  content:string
//   participants: { id: string; name: string }[];
}

interface Message {
  id: string;
  sender_id: string;
  content: string;
  timestamp: string;
}

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
}

interface MessagePanelProps {
  conversation: Conversation;
  messages: Message[];
  onSendMessage: (content: string) => void;
  currentUser: User | null;
}

const MessagePanel: React.FC<MessagePanelProps> = ({
  conversation,
  messages,
  onSendMessage,
  currentUser
}) => {
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to the bottom of the messages when they update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendClick = () => {
    if (newMessage.trim()) {
    //   onSendMessage(newMessage);
    alert("new message:"+newMessage)
        
    setNewMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendClick();
    }
  };

  // Determine conversation name (similar logic as ConversationList)
//   const otherParticipants = conversation.participants.filter(
    // p => currentUser && p.id !== currentUser.id
//   );
//   const conversationName = otherParticipants.length > 0
    // ? otherParticipants.map(p => `${p.first_name} ${p.last_name}`).join(', ')
    // : 'Self Chat';

    const conversationName = 'One to one Chat'

  return (
    <div className="flex flex-col h-full">
      {/* Conversation Header */}
      <div className="p-4 bg-gray-200 border-b border-gray-300 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800">{conversationName}</h2>
        <p className="text-sm text-gray-600">          
          From: {`${conversation.sender.first_name}  ${conversation.sender.last_name}`} <br></br>
          To:  {`${conversation.receiver.first_name} ${conversation.receiver.last_name}`}
        </p>

        <p className="text-sm text-gray-600">          
          Message: {`${conversation.content}`} 
        </p>
      </div>

      {/* Messages Display Area */}
      <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 mt-10">No messages yet. Start the conversation!</div>
        ) : (
          messages.map((message) => {
            const isMyMessage = currentUser && message.sender_id === currentUser.id;

            const senderName = conversation.sender;

            const formattedTime = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return (
              <div
                key={message.id}
                className={`flex mb-4 ${isMyMessage ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[70%] p-3 rounded-lg shadow-md ${
                    isMyMessage
                      ? 'bg-blue-500 text-white rounded-br-none'
                      : 'bg-gray-300 text-gray-800 rounded-bl-none'
                  }`}
                >
                  {!isMyMessage && (
                    <div className="font-semibold text-xs mb-1">
                      {senderName ? `${senderName.first_name} ${senderName.last_name}` : 'Unknown User'}
                    </div>
                  )}
                  <p className="text-sm">{message.content}</p>
                  <span className={`block text-xs mt-1 ${isMyMessage ? 'text-blue-100' : 'text-gray-600'} text-right`}>
                    {formattedTime}
                  </span>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} /> {/* Scroll target */}
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex rounded-full shadow-lg overflow-hidden border border-gray-300">
          <input
            type="text"
            className="flex-1 p-3 outline-none text-gray-800 placeholder-gray-400"
            placeholder="Type your message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <button
            onClick={handleSendClick}
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 transition duration-200 ease-in-out"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default MessagePanel;
