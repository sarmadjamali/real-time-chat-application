// src/components/SignInForm.tsx
import React, { useState } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { useDispatch } from 'react-redux'; // Import useDispatch
import { setAuthTokens } from '../redux/authSlice'; // Import your action

const SignInForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter(); // Initialize useRouter
  const dispatch = useDispatch(); // Initialize useDispatch

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Sign In:', { email, password });
    // Handle sign-in logic here (e.g., API call)

    try {

        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

        const urlencoded = new URLSearchParams();
        urlencoded.append("username", email);
        urlencoded.append("password", password);

        const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: urlencoded,
        redirect: "follow"
        };

        const response = await fetch("http://127.0.0.1:8000/sign-in", requestOptions);

        console.log(response.status)

        if (response.status == 200) {
            const data = await response.json();

            // Dispatch the action to store tokens in Redux
            dispatch(setAuthTokens({
                access_token: data.access_token,
                token_type: data.token_type,
            }));

            // Sign-up successful
            // alert('Sign-in successful! Please sign in.');
            router.push('/dashboard'); // Example: Redirect to a dashboard page
            // router.push('/?form=conversations'); 
        
        }else if(response.status == 401){
            // Handle sign-up errors (e.g., email already exists)
            const errorData = await response.json();
            alert(`Sign-in failed: ${errorData.detail}`)
        } else {
            // Handle sign-up errors (e.g., email already exists)
            const errorData = await response.json();
            alert(`Sign-in failed: ${errorData.message || 'Something went wrong.'}`);
        }
        } catch (error) {
            console.error('Error during sign-up:', error);
            alert('An unexpected error occurred. Please try again later.');
        }   

  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Sign In</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">
            Email
          </label>
          <input
            type="email"
            id="email"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="your@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="mb-6">
          <label htmlFor="password" className="block text-gray-700 text-sm font-bold mb-2">
            Password
          </label>
          <input
            type="password"
            id="password"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="********"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="flex items-center justify-between">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
          >
            Sign In
          </button>
        </div>
      </form>
    </div>
  );
};

export default SignInForm;