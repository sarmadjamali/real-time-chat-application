// src/components/Layout.tsx
import React from 'react';
// import { Inter } from 'next/font/google';
// import { ReduxProvider } from '../redux/Provider'; // Import your Redux Provider

interface LayoutProps {
  children: React.ReactNode;
}
// const inter = Inter({ subsets: ['latin'] });

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-white shadow p-4">
        <nav className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">Real time Chat Application</h1>
          <div>
            {/* You can add navigation links here if needed */}
          </div>
        </nav>
      </header>
      <main className="flex-grow container mx-auto p-4 flex items-center justify-center">
        {children} {/* Children directly here, without ReduxProvider */}
      </main>
      <footer className="bg-white shadow p-4 mt-auto">
        <div className="container mx-auto text-center text-gray-600">
          &copy; {new Date().getFullYear()} Real time Chat Application. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Layout;

// const Layout: React.FC<LayoutProps> = ({ children }) => {
//   return (
//     <div className="min-h-screen bg-gray-100 flex flex-col">
//       <header className="bg-white shadow p-4">
//         <nav className="container mx-auto flex justify-between items-center">
//           <h1 className="text-2xl font-bold text-gray-800">Real time Chat Application</h1>
//           <div>
//             {/* You can add navigation links here if needed */}
//           </div>
//         </nav>
//       </header>
//       <main className="flex-grow container mx-auto p-4 flex items-center justify-center">
//       <ReduxProvider> {/* Wrap your children with ReduxProvider */}
//           {children}
//         </ReduxProvider>
//         {/* {children}/ */}
//       </main>
//       <footer className="bg-white shadow p-4 mt-auto">
//         <div className="container mx-auto text-center text-gray-600">
//           &copy; {new Date().getFullYear()} Real time Chat Application. All rights reserved.
//         </div>
//       </footer>
//     </div>
//   );
// };

// export default Layout;