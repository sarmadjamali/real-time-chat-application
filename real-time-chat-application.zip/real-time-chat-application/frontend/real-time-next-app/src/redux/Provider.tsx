// src/redux/Provider.tsx
'use client'; // This component must be a client component

import { Provider } from 'react-redux';
import { store } from './store'; // Import your Redux store

interface ReduxProviderProps {
  children: React.ReactNode;
}

export function ReduxProvider({ children }: ReduxProviderProps) {
  return <Provider store={store}>{children}</Provider>;
}