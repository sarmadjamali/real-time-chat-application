// src/redux/authSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Define a type for the auth state
interface AuthState {
  accessToken: string | null;
  tokenType: string | null;
  isAuthenticated: boolean;
}

// Define the initial state using that type
const initialState: AuthState = {
  accessToken: null,
  tokenType: null,
  isAuthenticated: false,
};

export const authSlice = createSlice({
  name: 'auth', // This name is used in the Redux DevTools and for action types
  initialState,
  reducers: {
    // Action to set authentication data (login)
    setAuthTokens: (state, action: PayloadAction<{ access_token: string; token_type: string }>) => {
      state.accessToken = action.payload.access_token;
      state.tokenType = action.payload.token_type;
      state.isAuthenticated = true;
      // Optionally, you might want to store in localStorage/sessionStorage here
      // This helps persist login across tab closes or refreshes.
      // However, be cautious with sensitive data in localStorage.
      // For this basic setup, we'll keep it in Redux state first.
      // localStorage.setItem('accessToken', action.payload.access_token);
      // localStorage.setItem('tokenType', action.payload.token_type);
    },
    // Action to clear authentication data (logout)
    clearAuthTokens: (state) => {
      state.accessToken = null;
      state.tokenType = null;
      state.isAuthenticated = false;
      // Also clear from localStorage if stored
      // localStorage.removeItem('accessToken');
      // localStorage.removeItem('tokenType');
    },
  },
});

// Export actions
export const { setAuthTokens, clearAuthTokens } = authSlice.actions;

// Export the reducer
export default authSlice.reducer;