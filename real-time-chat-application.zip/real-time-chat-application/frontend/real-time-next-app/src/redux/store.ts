// src/redux/store.ts
import { configureStore } from '@reduxjs/toolkit';
import authReducer from './authSlice'; // Import the auth reducer

export const store = configureStore({
  reducer: {
    auth: authReducer, // Assign the auth reducer to the 'auth' slice of your state
  },
  // You can add middleware here if needed (e.g., redux-thunk is included by default)
  // devTools: process.env.NODE_ENV !== 'production', // Enable Redux DevTools in development
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {auth: AuthState}
export type AppDispatch = typeof store.dispatch;