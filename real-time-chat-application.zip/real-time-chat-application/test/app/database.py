# database.py
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Replace with your PostgreSQL connection string
# Example: "postgresql://user:password@host:port/database_name"
# For local development, it might look like: "postgresql://postgres:password@localhost:5432/chat_db"
SQLALCHEMY_DATABASE_URL = "postgresql://user:postgres@localhost:5433/real-time-chat-application"

# Create the SQLAlchemy engine
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Create a SessionLocal class, which will be an instance of Session
# Each instance of SessionLocal will be a database session
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for our SQLAlchemy models
Base = declarative_base()

# Dependency to get a database session
# This function will be used with FastAPI's Depends to manage database sessions
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()