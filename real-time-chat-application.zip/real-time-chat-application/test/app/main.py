# from typing import Union

# from fastapi import FastAPI

# app = FastAPI()


# @app.get("/")
# def read_root():
#     return {"Hello": "World"}


# @app.get("/items/{item_id}")
# def read_item(item_id: int, q: Union[str, None] = None):
#     return {"item_id": item_id, "q": q}




# main.py
from fastapi import FastAPI, Depends, HTTPException, status, WebSocket, WebSocketDisconnect
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from datetime import timedelta
from typing import List, Dict, Optional
import json

import models
import schemas
import utils
from database import engine, get_db

# Create all database tables (for initial setup, Alembic will handle migrations later)
# models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Real-time Chat Application",
    description="A real-time chat application built with FastAPI and WebSockets.",
    version="1.0.0"
)

# OAuth2PasswordBearer for token authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# --- Authentication and Authorization ---

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    """
    Dependency to get the current authenticated user.
    Decodes the JWT token and fetches the user from the database.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = utils.decode_access_token(token)
    if payload is None:
        raise credentials_exception
    email: str = payload.get("sub", "")  # Provide a default string value
    if email is None or email == "":
        raise credentials_exception
    user = db.query(models.User).filter(models.User.email == email).first()
    if user is None:
        raise credentials_exception
    return user

# --- WebSocket Manager for Real-time Chat ---

class ConnectionManager:
    """
    Manages active WebSocket connections and handles broadcasting messages.
    """
    def __init__(self):
        # Dictionary to store active connections: {user_id: WebSocket}
        self.active_connections: Dict[int, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        """Establishes a new WebSocket connection for a user."""
        await websocket.accept()
        self.active_connections[user_id] = websocket
        print(f"User {user_id} connected.")

    def disconnect(self, user_id: int):
        """Removes a disconnected user's WebSocket connection."""
        if user_id in self.active_connections:
            del self.active_connections[user_id]
            print(f"User {user_id} disconnected.")

    async def send_personal_message(self, message: str, user_id: int):
        """Sends a message to a specific user."""
        if user_id in self.active_connections:
            await self.active_connections[user_id].send_text(message)

    async def broadcast(self, message: str, exclude_user_id: Optional[int] = None):
        """Broadcasts a message to all active connections (excluding an optional user)."""
        for user_id, connection in self.active_connections.items():
            if user_id != exclude_user_id:
                await connection.send_text(message)

manager = ConnectionManager()

# --- API Endpoints ---

@app.post("/register", response_model=schemas.User, status_code=status.HTTP_201_CREATED)
async def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    """
    Registers a new user.
    Hashes the password before storing it in the database.
    """
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

    hashed_password = utils.get_password_hash(user.password)
    db_user = models.User(
        first_name=user.first_name,
        last_name=user.last_name,
        email=user.email,
        hashed_password=hashed_password
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.post("/token", response_model=schemas.Token)
async def login_for_access_token(form_data: schemas.UserLogin, db: Session = Depends(get_db)):
    """
    Authenticates a user and returns an access token.
    """
    user = db.query(models.User).filter(models.User.email == form_data.email).first()
    if not user or not utils.verify_password(form_data.password, str(user.hashed_password)):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=utils.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = utils.create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/users/me", response_model=schemas.User)
async def read_users_me(current_user: models.User = Depends(get_current_user)):
    """
    Retrieves the details of the currently authenticated user.
    """
    return current_user

@app.get("/users", response_model=List[schemas.User])
async def get_all_users(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """
    Retrieves a list of all registered users.
    """
    users = db.query(models.User).all()
    return users

# --- WebSocket Endpoint for Chat ---

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int, db: Session = Depends(get_db)):
    """
    WebSocket endpoint for real-time chat.
    Connects users and handles message sending/receiving.
    """
    # In a real application, you'd verify the user_id with an authentication token
    # For simplicity, we're assuming the user_id is valid for demonstration.
    # A more secure approach would involve authenticating the user via a token
    # passed in the WebSocket connection URL or header.

    # Check if user exists
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="User not found")
        return

    await manager.connect(websocket, user_id)
    try:
        while True:
            data = await websocket.receive_text()
            # Expected data format: {"receiver_id": int, "content": "message text"}
            try:
                message_data = json.loads(data)
                receiver_id = message_data.get("receiver_id")
                content = message_data.get("content")

                if not receiver_id or not content:
                    await manager.send_personal_message(
                        json.dumps({"error": "Invalid message format. Requires 'receiver_id' and 'content'."}),
                        user_id
                    )
                    continue

                # Check if receiver exists
                receiver = db.query(models.User).filter(models.User.id == receiver_id).first()
                if not receiver:
                    await manager.send_personal_message(
                        json.dumps({"error": f"Receiver with ID {receiver_id} not found."}),
                        user_id
                    )
                    continue

                # Save message to database
                new_message = models.Message(
                    sender_id=user_id,
                    receiver_id=receiver_id,
                    content=content
                )
                db.add(new_message)
                db.commit()
                db.refresh(new_message)

                # Prepare message for broadcasting
                message_to_send = {
                    "sender_id": user_id,
                    "receiver_id": receiver_id,
                    "content": content,
                    "timestamp": new_message.timestamp.isoformat()
                }

                # Send message to sender (for confirmation/display in their own chat)
                await manager.send_personal_message(json.dumps(message_to_send), user_id)

                # Send message to receiver
                if receiver_id in manager.active_connections:
                    await manager.send_personal_message(json.dumps(message_to_send), receiver_id)
                else:
                    print(f"Receiver {receiver_id} is not currently online.")
                    # In a real app, you might store this as an unread message
                    # or notify the sender that the receiver is offline.

            except json.JSONDecodeError:
                await manager.send_personal_message(
                    json.dumps({"error": "Invalid JSON format."}),
                    user_id
                )
            except Exception as e:
                print(f"Error processing WebSocket message: {e}")
                await manager.send_personal_message(
                    json.dumps({"error": f"An internal error occurred: {str(e)}"}),
                    user_id
                )

    except WebSocketDisconnect:
        manager.disconnect(user_id)
    except Exception as e:
        print(f"WebSocket error for user {user_id}: {e}")
        manager.disconnect(user_id)
