# models.py
from sqlalchemy import Column, Integer, String,Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    """
    SQLAlchemy model for the 'users' table.
    Represents a user in the chat application.
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String, index=True)
    last_name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String, nullable=False) # Store hashed password
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Define a relationship with the Message model
    # 'back_populates' creates a bidirectional relationship
    sent_messages = relationship("Message", back_populates="sender", foreign_keys="[Message.sender_id]")
    received_messages = relationship("Message", back_populates="receiver", foreign_keys="[Message.receiver_id]")

class Message(Base):
    """
    SQLAlchemy model for the 'messages' table.
    Represents a chat message exchanged between users.
    """
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey("users.id")) # Foreign key to the users table
    receiver_id = Column(Integer, ForeignKey("users.id")) # Foreign key to the users table
    content = Column(String, index=True)
    is_read = Column(Boolean, default=0,index = True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

    # Define relationships with the User model
    sender = relationship("User", back_populates="sent_messages", foreign_keys=[sender_id])
    receiver = relationship("User", back_populates="received_messages", foreign_keys=[receiver_id])
