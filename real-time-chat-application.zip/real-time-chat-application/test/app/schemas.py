# schemas.py
from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

class UserBase(BaseModel):
    """Base schema for user data."""
    email: EmailStr

class UserCreate(UserBase):
    """Schema for creating a new user."""
    first_name: str
    last_name: str
    password: str

class UserLogin(UserBase):
    """Schema for user login."""
    password: str

class User(UserBase):
    """Schema for returning user data (excluding password hash)."""
    id: int
    first_name: str
    last_name: str
    created_at: datetime

    class Config:
        orm_mode = True # Enable ORM mode for SQLAlchemy compatibility

class Token(BaseModel):
    """Schema for JWT token."""
    access_token: str
    token_type: str

class TokenData(BaseModel):
    """Schema for data contained within a JWT token."""
    email: Optional[str] = None

class MessageCreate(BaseModel):
    """Schema for creating a new message."""
    receiver_id: int
    content: str

class Message(BaseModel):
    """Schema for returning message data."""
    id: int
    sender_id: int
    receiver_id: int
    content: str
    timestamp: datetime

    class Config:
        orm_mode = True # Enable ORM mode for SQLAlchemy compatibility
